import hashlib
import json
import sqlite3
import tempfile
from contextlib import closing
from pathlib import Path


REQUEST = b'{"request_id":"request-001","refund_id":"refund-001","amount_pence":2500,"currency":"GBP","approval_version":1}'
REQUEST_HASH = hashlib.sha256(REQUEST).hexdigest()
ACTIVE = (1, "ACTIVE", REQUEST_HASH)
WITHDRAWN = (2, "WITHDRAWN", REQUEST_HASH)


def read_state(path, table):
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as db:
        return db.execute(f"SELECT version, status, digest FROM {table}").fetchone()


def setup(folder):
    folder.mkdir()
    authority = folder / "authority.sqlite"
    ledger = folder / "receiver.sqlite"
    for path, table in ((authority, "authority"), (ledger, "inbox")):
        with closing(sqlite3.connect(path)) as db, db:
            db.execute(f"CREATE TABLE {table}(version INTEGER, status TEXT, digest TEXT)")
            db.execute(f"INSERT INTO {table} VALUES (?, ?, ?)", ACTIVE)
            if path == ledger:
                db.execute("CREATE TABLE effects(id TEXT PRIMARY KEY, pence INTEGER, currency TEXT, digest TEXT)")
    return authority, ledger


def withdraw(path):
    with closing(sqlite3.connect(path)) as db, db:
        db.execute("UPDATE authority SET version=?, status=?, digest=?", WITHDRAWN)


def deliver(authority, ledger):
    state = read_state(authority, "authority")
    with closing(sqlite3.connect(ledger)) as db, db:
        db.execute("UPDATE inbox SET version=?, status=?, digest=?", state)


def receive(raw, ledger, obtain_standing):
    standing = obtain_standing()
    if standing is None:
        return "HOLD"
    digest = hashlib.sha256(raw).hexdigest()
    request = json.loads(raw)
    if standing != (request["approval_version"], "ACTIVE", digest):
        return "REFUSE"
    with closing(sqlite3.connect(ledger)) as db, db:
        db.execute("INSERT INTO effects VALUES (?, ?, ?, ?)", (
            request["refund_id"], request["amount_pence"], request["currency"], digest,
        ))
    return "COMMIT"


def observe(ledger):
    with closing(sqlite3.connect(ledger.as_uri() + "?mode=ro", uri=True)) as db:
        integrity = db.execute("PRAGMA integrity_check").fetchone()
        assert integrity == ("ok",), integrity
        return db.execute("SELECT id, pence, currency, digest FROM effects ORDER BY id").fetchall()


def check(label, ledger, outcome, expected_outcome, expected_rows):
    actual_rows = observe(ledger)
    assert (outcome, actual_rows) == (expected_outcome, expected_rows), (outcome, actual_rows)
    print(json.dumps({"checkpoint": label, "decision": outcome, "effects": actual_rows}))


def main(root):
    expected_effect = [("refund-001", 2500, "GBP", REQUEST_HASH)]
    authority, ledger = setup(root / "delayed")
    withdraw(authority)
    assert read_state(authority, "authority") == WITHDRAWN
    assert read_state(ledger, "inbox") == ACTIVE
    check("withdrawal committed upstream, delivery delayed, source unavailable",
          ledger, receive(REQUEST, ledger, lambda: None), "HOLD", [])
    deliver(authority, ledger)
    assert read_state(ledger, "inbox") == WITHDRAWN
    check("withdrawal delivered, source available, identical retry",
          ledger, receive(REQUEST, ledger, lambda: read_state(authority, "authority")), "REFUSE", [])

    authority, ledger = setup(root / "active")
    check("matched active approval, current source available",
          ledger, receive(REQUEST, ledger, lambda: read_state(authority, "authority")), "COMMIT", expected_effect)

    authority, ledger = setup(root / "cached")
    withdraw(authority)
    assert read_state(authority, "authority") == WITHDRAWN
    assert read_state(ledger, "inbox") == ACTIVE
    check("deliberate cached-approval control, effect detected after withdrawal",
          ledger, receive(REQUEST, ledger, lambda: read_state(ledger, "inbox")), "COMMIT", expected_effect)


if __name__ == "__main__":
    print(json.dumps({"sqlite": sqlite3.sqlite_version, "request_sha256": REQUEST_HASH}))
    with tempfile.TemporaryDirectory() as directory:
        main(Path(directory))
