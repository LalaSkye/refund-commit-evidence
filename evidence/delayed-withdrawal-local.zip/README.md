# The £25 Refund Test — delayed withdrawal

Private review copy. This package contains one captured local rerun of the original scratch harness, with newly retained output and final databases. The original local run printed the same four outcomes and used SQLite 3.53.1. Its disposable databases were removed at exit.

Run from an extracted copy with `python -B checkpoint.py`. The standalone command uses temporary databases. RUN.jsonl records the packaged rerun, including its runtime and exact request hash. The databases directory contains the final authority and receiver files from that run. SHA256SUMS covers every payload file.

| Checkpoint | Decision | Committed refund effects |
| --- | --- | ---: |
| Upstream withdrawal committed, delivery delayed, source unavailable | HOLD | 0 |
| Withdrawal delivered and source available, identical retry | REFUSE | 0 |
| Active authority available in the matched control | COMMIT | 1 × £25 |
| Deliberate cached-approval control after withdrawal | COMMIT | 1 × £25, detected |

HOLD is a non-final return value. It writes neither a decision nor an effect to the receiver ledger. The receiver evaluates the same request afresh on retry. The harness reopens the ledger read-only after each checkpoint. The final database from the delayed schedule reflects the state after REFUSE. The earlier zero-effect observation at HOLD is in RUN.jsonl.

The harness simulates delayed delivery by deferring the copy of the withdrawal into the receiver inbox. It simulates source unavailability by returning no current authority from the source callback. This is a sequential local synthetic test with no real payments, network fault test, cross-database commit guarantee or independent reproduction.

The earlier single-database checkpoint and its GitHub Actions run are separate evidence.
